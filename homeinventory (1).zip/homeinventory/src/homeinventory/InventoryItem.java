package homeinventory;
import java.io.*;

class InventoryItem {
    public String description;
    public String location;
    public boolean marked;
    public String serialNumber;
    public String purchasePrice;
    public String purchaseDate;
    public String purchaseLocation;
    public String note;
    public String photoFile;


    // Rest of the class...

    public static void main(String args[]) {
        InventoryItem myItem = new InventoryItem();
        myItem.description = "This is my inventory item";
        // Set other properties as needed...
    }
}
